global using StrategyService.Services;
