using Microsoft.Extensions.Options; 
using TradingSystem.Application.Healing; 
using TradingSystem.Application.Positions; 
using TradingSystem.Application.Time; 
using TradingSystem.Contracts.UserStream;

namespace StrategyService.Bots.Bot8012;

public sealed class Bot8012HealingService(
    IOptions<Bot8012Options> options, 
    IPositionStore store, 
    IClock clock, 
    ILogger<Bot8012HealingService> logger)
    :IBotHealingService
{
    private readonly Bot8012Options _o = options.Value;
    
    public string BotName => _o.BotName;
    
    public async Task HealAsync(HealingSnapshotMessage s, CancellationToken ct)
    {
        if(!_o.EnableHealing || !s.Symbol.Equals(_o.Symbol, StringComparison.OrdinalIgnoreCase))
            return;
        
        var active = s.ActiveClientIds.ToHashSet(StringComparer.OrdinalIgnoreCase);
        
        foreach(var p in (await store.GetAllAsync(BotName, ct)).Where(x => !x.Closed && !string.IsNullOrWhiteSpace(x.TpClientId) && !active.Contains(x.TpClientId!)))
        {
            p.MarkClosed("HEALING_ORDER_ABSENT", clock.UtcNow);
            
            await store.SaveAsync(p, ct);
            
            logger.LogWarning("Position reconciled as closed. Bot = {Bot} Position = {Position}", BotName, p.ShortId);
        }
    }
}
