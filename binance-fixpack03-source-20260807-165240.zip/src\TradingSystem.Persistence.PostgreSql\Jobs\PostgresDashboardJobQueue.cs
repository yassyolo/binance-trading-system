using Dapper;
using TradingSystem.JobOrchestration;
using TradingSystem.Persistence.PostgreSql.Connections;

namespace TradingSystem.Persistence.PostgreSql.Jobs;

public sealed class PostgresDashboardJobQueue(ITradingDbConnectionFactory factory) : IDashboardJobQueue
{
    public async Task<IReadOnlyList<DashboardJob>> ClaimAsync(string type, string workerId, int batchSize, TimeSpan timeout, CancellationToken ct)
    {
        const string sql = """
with picked as (
    select job_id
    from trading_dashboard.jobs
    where type = @type
      and (
        (status = 'Pending' and (next_attempt_at_utc is null or next_attempt_at_utc <= now()))
        or
        (status = 'Processing' and processing_started_at_utc < now() - @timeout)
      )
    order by created_at_utc
    for update skip locked
    limit @take
)
update trading_dashboard.jobs j
set status = 'Processing',
    processing_worker_id = @worker,
    processing_started_at_utc = now(),
    started_at_utc = coalesce(started_at_utc, now()),
    attempt_count = attempt_count + 1
from picked
where j.job_id = picked.job_id
returning j.job_id JobId,
          j.type Type,
          j.status Status,
          j.requested_by RequestedBy,
          j.request::text RequestJson,
          j.attempt_count AttemptCount,
          j.created_at_utc CreatedAtUtc,
          j.started_at_utc StartedAtUtc;
""";
        await using var c = await factory.OpenAsync(ct);
        var rows = await c.QueryAsync<DashboardJob>(
            new CommandDefinition(
                sql,
                new { type, worker = workerId, take = Math.Clamp(batchSize, 1, 20), timeout },
                cancellationToken: ct
            )
        );
        return rows.AsList();
    }

    public async Task ReportProgressAsync(Guid id, int percent, string stage, CancellationToken ct)
    {
        await using var c = await factory.OpenAsync(ct);
        await c.ExecuteAsync(
            new CommandDefinition(
                "update trading_dashboard.jobs set progress_percent = @percent, progress_stage = @stage where job_id = @id and status = 'Processing'",
                new { id, percent = Math.Clamp(percent, 0, 100), stage },
                cancellationToken: ct
            )
        );
    }

    public async Task CompleteAsync(Guid id, Guid runId, CancellationToken ct)
    {
        await using var c = await factory.OpenAsync(ct);
        await c.ExecuteAsync(
            new CommandDefinition(
                "update trading_dashboard.jobs set status = 'Completed', result_run_id = @runId, progress_percent = 100, progress_stage = 'Completed', completed_at_utc = now(), processing_worker_id = null where job_id = @id",
                new { id, runId },
                cancellationToken: ct
            )
        );
    }

    public async Task FailAsync(Guid id, string error, int maxAttempts, TimeSpan retry, CancellationToken ct)
    {
        await using var c = await factory.OpenAsync(ct);
        await c.ExecuteAsync(
            new CommandDefinition(
                "update trading_dashboard.jobs set status = case when attempt_count>=@max then 'Failed' else 'Pending' end, error = @error, next_attempt_at_utc = case when attempt_count>=@max then null else now()+@retry end, completed_at_utc = case when attempt_count>=@max then now() else null end, processing_worker_id = null where job_id = @id",
                new { id, error = error[..Math.Min(error.Length, 4000)], max = maxAttempts, retry },
                cancellationToken: ct
            )
        );
    }
}
